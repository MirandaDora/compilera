
/*-----------------------------------------------------------------------
 Declarations for the pretty printer for Wiz programs.
 For use in the COMP90045 project 2014.

    Team:       Master Minds
    Members:    629204 Ye He
                547108 Yi Xia
                645452 Rongzuo Liu 
 -----------------------------------------------------------------------*/

#include "std.h"
#include "ast.h"

void pretty_prog(FILE *, Program);


